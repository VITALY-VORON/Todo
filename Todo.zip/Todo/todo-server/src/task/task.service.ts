import { BadRequestException, Injectable } from '@nestjs/common';
import { CreateTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { TaskRepository } from './repositories/task.repository';

@Injectable()
export class TaskService {
  constructor(private taskRepository: TaskRepository) { }

  public async createNewTask(
    { title, description, status }: CreateTaskDto,
  ) {
    const Task = this.taskRepository.create({ title, description, status });
    return await this.taskRepository.save(Task);
  }

  public async getAllTasks() {
    return await this.taskRepository.find();
  }

  public async getTaskById(id: string) {
    return await this.taskRepository.findOne({ where: { id } });
  }

  public async deleteTaskById(id: string) {
    return await this.taskRepository.delete(id);
  }

  public async updateTaskById(
    id: string,
    { newTitle, newDescription, newStatus }: UpdateTaskDto,
  ) {
    const task = await this.getTaskById(id);
    if (!task) throw new BadRequestException(`Task ${id} does not exist`);
    return await this.taskRepository.update(
      { id: task.id },
      { title: newTitle, description: newDescription, status: newStatus },
    );
  }
}
