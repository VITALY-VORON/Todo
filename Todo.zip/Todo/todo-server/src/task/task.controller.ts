import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Delete,
  Patch,
} from '@nestjs/common';
import { TaskService } from './task.service';
import { CreateTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';

@Controller('task')
export class TaskController {
  constructor(private readonly taskService: TaskService) {}

  @Post('/create-task/')
  CreateNewTask(
    @Body() createTaskDto: CreateTaskDto,
  ) {
    return this.taskService.createNewTask(createTaskDto);
  }

  @Get('/get-tasks')
  GetAllTasks() {
    return this.taskService.getAllTasks();
  }

  @Get('/get-task/:id')
  GetTaskById(@Param('id') id: string) {
    return this.taskService.getTaskById(id);
  }

  @Delete('/delete-task/:id')
  DeleteTaskById(@Param('id') id: string) {
    return this.taskService.deleteTaskById(id);
  }

  @Patch('/update-task/:id')
  async UpdateTaskById(
    @Param('id') id: string,
    @Body() updateTaskDto: UpdateTaskDto,
  ) {
    return await this.taskService.updateTaskById(id, updateTaskDto);
  }
}
