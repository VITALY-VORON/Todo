import { Repository } from 'typeorm';
import { TaskEntity } from '../entities/task.entity';
import { CustomRepository } from './typeotm.custom.repository';

@CustomRepository(TaskEntity)
export class TaskRepository extends Repository<TaskEntity> {}
