import { SetMetadata } from '@nestjs/common';

export const TYPEORM_CUSTOM_REPOSITORY = 'TYPEORM_CUSTOM_REPOSITORY';

export const CustomRepository = <T extends new (...args: any[]) => any>(
  entity: T,
): ClassDecorator => {
  return SetMetadata(TYPEORM_CUSTOM_REPOSITORY, entity);
};
